# 🚀 Haimeta营销日历系统 - 完整部署教程

## 📋 部署清单

✅ = 必做 | ⚠️ = 可选但推荐 | 💡 = 完全可选

- ✅ GitHub账号
- ⚠️ Hugging Face账号 (AI配图Prompt)
- ⚠️ Google Cloud账号 (YouTube监控)
- ✅ 飞书账号
- ✅ 15分钟时间

---

## 第一步: GitHub仓库部署 (5分钟)

### 1.1 创建GitHub仓库

1. 登录 https://github.com
2. 点击右上角 `+` > `New repository`
3. 填写信息:
   - Repository name: `marketing-calendar-api`
   - Description: `Haimeta营销日历自动生成系统`
   - 选择 `Public` (这样才能用GitHub Pages)
   - ✅ 勾选 `Add a README file`
4. 点击 `Create repository`

### 1.2 上传代码

**方式A: 网页直接上传 (推荐)**

1. 在你的仓库页面,点击 `Add file` > `Upload files`
2. 拖拽以下文件:
   - `marketing_calendar_generator.py`
   - `README.md`
3. 创建目录 `.github/workflows/`,上传:
   - `daily-update.yml`
4. Commit changes

**方式B: Git命令行**

```bash
git clone https://github.com/YOUR_USERNAME/marketing-calendar-api.git
cd marketing-calendar-api

# 复制文件到此目录
cp /path/to/marketing_calendar_generator.py .
cp /path/to/README.md .
mkdir -p .github/workflows
cp /path/to/daily-update.yml .github/workflows/

git add .
git commit -m "Initial commit: Marketing Calendar Generator"
git push
```

### 1.3 配置GitHub Pages

1. 进入仓库 `Settings` > `Pages`
2. Source: 选择 `Deploy from a branch`
3. Branch: 选择 `main` > `/root`
4. 点击 `Save`
5. 等待1分钟,访问 `https://YOUR_USERNAME.github.io/marketing-calendar-api/output/latest.json`

---

## 第二步: 配置API密钥 (可选,5分钟)

### 2.1 Hugging Face Token (可选)

**用途:** AI配图Prompt生成

1. 注册 https://huggingface.co/join
2. 访问 https://huggingface.co/settings/tokens
3. 点击 `New token`
   - Name: `marketing-calendar`
   - Role: `Read`
4. 复制Token (格式: `hf_xxxxxxxxxxxxxx`)
5. 在GitHub仓库: `Settings` > `Secrets and variables` > `Actions` > `New repository secret`
   - Name: `HF_TOKEN`
   - Value: 粘贴你的Token
6. 点击 `Add secret`

### 2.2 YouTube API Key (可选)

**用途:** YouTube热门视频监控

1. 访问 https://console.cloud.google.com/
2. 创建新项目 (或选择现有项目)
3. 启用API:
   - 搜索 `YouTube Data API v3`
   - 点击 `Enable`
4. 创建凭据:
   - `Credentials` > `Create Credentials` > `API Key`
5. 复制API Key
6. 在GitHub添加Secret:
   - Name: `YOUTUBE_API_KEY`
   - Value: 粘贴API Key

---

## 第三步: 启用GitHub Actions (1分钟)

1. 进入仓库 `Actions` 标签
2. 点击绿色按钮 `I understand my workflows, go ahead and enable them`
3. 点击左侧 `Daily Marketing Calendar Update`
4. 点击右侧 `Run workflow` > `Run workflow` (绿色按钮)
5. 等待30秒,刷新页面,查看运行状态
6. ✅ 绿色对勾 = 成功
7. 访问 `https://YOUR_USERNAME.github.io/marketing-calendar-api/output/latest.json` 查看生成的JSON

---

## 第四步: 配置飞书自动化 (10分钟)

### 4.1 创建飞书多维表格

1. 打开飞书,创建新多维表格
2. 表名: `📅 Haimeta全球营销日历`
3. 创建以下字段:

| 字段名 | 类型 | 示例值 |
|--------|------|--------|
| 日期 | 日期 | 2026-01-23 |
| 热点名称(中) | 文本(单行) | 农历小年 |
| 热点名称(英) | 文本(单行) | Chinese Little New Year |
| 类型标签 | 多选 | 添加选项: 节日营销/竞品功能/热点事件/行业趋势/用户行为/提前预警 |
| 优先级 | 单选 | 添加选项: 🔥高/⭐中/💡低 |
| 目标受众 | 文本(单行) | 海外华人社区 |
| 文案标题(中) | 文本(单行) | 🎨 农历小年 \| Haimeta助你抢占节日营销先机 |
| 文案正文(中) | 文本(多行) | 把握农历小年营销窗口... |
| 文案标题(英) | 文本(单行) | 🎨 Chinese Little New Year \| Create Stunning Visuals |
| 文案正文(英) | 文本(多行) | Leverage AI to create... |
| AI配图Prompt | 文本(多行) | 农历小年主题,温馨节日氛围... |
| 时机建议 | 文本(单行) | 提前3天预热 |
| 状态 | 单选 | 添加选项: 待策划/进行中/已完成 |

### 4.2 配置自动化流程

1. 点击右上角 `自动化` 按钮
2. 点击 `+ 创建流程`

**⚙️ 触发器配置:**
- 选择 `定时触发`
- 重复频率: `每天`
- 触发时间: `09:00`
- 时区: `GMT+08:00 (Asia/Shanghai)`
- 点击 `确定`

**⚙️ 动作1: 发送HTTP请求**
- 添加动作 > 选择 `发送HTTP请求`
- 请求方式: `GET`
- URL: `https://YOUR_GITHUB_USERNAME.github.io/marketing-calendar-api/output/latest.json`
  - ⚠️ 替换 `YOUR_GITHUB_USERNAME` 为你的GitHub用户名
  - ⚠️ 确保路径是 `/output/latest.json`
- 响应存储为: `calendar_data`
- 点击 `确定`

**⚙️ 动作2: 循环 (重要!)**
- 添加动作 > 选择 `循环`
- 循环对象: 点击 `+` > 选择 `上一步响应` > `calendar_data` > `events`
- 在循环内部,添加子动作:

**⚙️ 动作2.1: 创建记录**
- 添加动作 > 选择 `创建记录`
- 目标表: 选择你刚创建的表格
- 字段映射 (点击每个字段右侧的 `+` 选择变量):

```
日期 ← 循环项 > date
热点名称(中) ← 循环项 > event_name
热点名称(英) ← 循环项 > event_name_en
类型标签 ← 循环项 > type
优先级 ← 循环项 > priority
目标受众 ← 循环项 > target_audience
文案标题(中) ← 循环项 > marketing_copy > zh > headline
文案正文(中) ← 循环项 > marketing_copy > zh > body
文案标题(英) ← 循环项 > marketing_copy > en > headline
文案正文(英) ← 循环项 > marketing_copy > en > body
AI配图Prompt ← 循环项 > image_prompts > [0] > prompt_zh
时机建议 ← 循环项 > timing_suggestion
```

- 点击 `确定`

**⚙️ 动作3: 发送通知**
- 退出循环块
- 添加动作 > 选择 `发消息`
- 发送给: 选择你的飞书群或个人
- 消息内容:
```
📅 营销日历已更新！

今日共抓取 [点击+选择 calendar_data > total_events] 个热点

查看完整日历 → [表格链接]
```

3. 点击右上角 `保存` > `启用`

### 4.3 测试运行

1. 点击 `立即运行`
2. 等待10-30秒
3. 查看飞书表格,应该看到新增记录
4. 检查飞书群消息

---

## 第五步: 验证完整流程 (2分钟)

### ✅ GitHub Actions自动运行

- 明天早上9点,GitHub Actions会自动运行
- 进入 `Actions` 标签查看历史记录

### ✅ 飞书自动更新

- 明天早上9点,飞书表格会自动新增记录
- 你会收到飞书通知

### ✅ 手动测试

**GitHub:**
- 进入 `Actions` > `Daily Marketing Calendar Update` > `Run workflow`

**飞书:**
- 进入自动化流程 > 点击 `立即运行`

---

## 🎯 成功标准

部署成功后,你应该能做到:

- ✅ 访问 GitHub Pages URL,看到JSON数据
- ✅ 飞书表格每天自动更新
- ✅ 飞书群每天收到通知
- ✅ 所有字段都正确映射

---

## ❓ 常见问题

### Q1: GitHub Pages显示404
**A:** 等待5-10分钟,GitHub Pages需要时间部署。检查 `Settings` > `Pages` 是否配置正确。

### Q2: GitHub Actions运行失败
**A:** 
1. 检查 `.github/workflows/daily-update.yml` 文件是否存在
2. 查看错误日志,通常是文件路径问题
3. 确保 `marketing_calendar_generator.py` 在根目录

### Q3: 飞书自动化无法获取数据
**A:** 
1. 确认GitHub Pages URL可以访问
2. 检查URL是否正确(替换了YOUR_GITHUB_USERNAME)
3. 尝试手动访问URL,看是否返回JSON

### Q4: 飞书字段映射找不到变量
**A:**
1. 确保 `发送HTTP请求` 步骤正确存储为 `calendar_data`
2. 刷新页面重试
3. 检查JSON格式是否正确

### Q5: YouTube API没有数据
**A:**
1. 检查是否配置了 `YOUTUBE_API_KEY` Secret
2. 检查API Key是否有效
3. YouTube API每天有1万次免费额度,检查是否超限

---

## 🎉 下一步优化

部署成功后,你可以:

1. **增加数据源:**
   - 编辑 `marketing_calendar_generator.py`
   - 添加更多节日到 `GLOBAL_HOLIDAYS`
   - 集成更多竞品RSS源

2. **优化文案:**
   - 调整 `generate_marketing_copy()` 函数
   - 添加更多文案模板

3. **调整推送时间:**
   - 编辑 `.github/workflows/daily-update.yml`
   - 修改 `cron: '0 1 * * *'` (当前是北京时间9:00)
   - 例如改成 `0 0 * * *` 就是北京时间8:00

4. **增加预警天数:**
   - 修改 `get_global_holidays()` 函数中的 `range(1, 8)` 

---

## 📞 技术支持

遇到问题请:
1. 检查本文档的常见问题部分
2. 查看GitHub Actions运行日志
3. 查看飞书自动化运行日志
4. 联系ZZ或Haimeta产品团队

---

**祝部署顺利! 🚀**
